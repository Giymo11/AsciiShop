/**
 * Created by Giymo11 on 16.02.2015.
 */
public class OperationException extends Exception {

    public OperationException() {
        super();
    }

    public OperationException(String message) {
        super(message);
    }
}
