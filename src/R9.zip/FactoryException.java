/**
 * Created by Giymo11 on 17.02.2015.
 */
public class FactoryException extends Exception {

    public FactoryException() {
        super();
    }

    public FactoryException(String message) {
        super(message);
    }
}
